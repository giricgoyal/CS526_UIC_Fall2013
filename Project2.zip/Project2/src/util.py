#-------------------------------------------------------
#	util.py file for utility stuff
#-------------------------------------------------------
from math import *
from euclid import *
from omega import *
from cyclops import *

# -------------------------------------------------------------
# class definitions
# class for bodyOrbit data
class bodyOrbit:
	name = ""
	radius = 0.0
	minorA = 0.0
	majorA = 0.0
	eccentricity = 0.0
	inclination = 0.0
	period = 0.0
	rotation = 0.0
	starType = ""
	isStar = 0
	texture = ""
	
	# getter methods
	def __getitem__(self, name):
		return name
	def __getitem__(self, radius):
		return radius
	def __getitem__(self, minorA):
		return minorA
	def __getitem__(self, majorA):
		return majorA
	def __getitem__(self, eccentricity):
		return eccentricity
	def __getitem__(self, inclination):
		return inclination
	def __getitem__(self, period):
		return period
	def __getitem__(self, rotation):
		return rotation
	def __getitem__(self, starType):
		return starType
	def __getitem__(self, isStar):
		return isStar
	def __getitem__(self, texture):
		return texture
		
	# constructor
	def __init__(self, name, radius, majorA, eccentricity, inclination, period, rotation, starType, isStar):
		self.name = name
		if isStar == 0:
			self.radius = radius * rJupiter #kms
			self.period = period * DAYtoYEAR #years
		else:
			self.radius = radius * rSun #kms
			self.period = 1.0 #years
		self.majorA = majorA * AUtoKM #kms
		self.eccentricity = eccentricity
		self.inclination = inclination
		self.rotation = rotation #days
		self.starType = starType
		self.minorA = getOrbitCoords(eccentricity, majorA) * AUtoKM #kms
		self.isStar = isStar
		if isStar == 1:
			if name == "The Sun":
				self.texture = "data/textures/stars/sol.png"
			if starType.find('A') != -1:
				self.texture = "data/textures/stars/astar.jpg"
			elif starType.find('B') != -1:
				self.texture = "data/textures/stars/bstar.png"
			elif starType.find('G') != -1:
				self.texture = "data/textures/stars/gstar.png"
			elif starType.find('K') != -1:
				self.texture = "data/textures/stars/kstar.png"
			elif starType.find('F') != -1:
				self.texture = "data/textures/stars/fstar.png"
			elif starType.find('M') != -1:
				self.texture = "data/textures/stars/mstar.png"
			elif starType.find('O') != -1:
				self.texture = "data/textures/stars/ostar.png"
		else:
			if name == "Mercury":
				self.texture = "data/textures/planets/mercury.jpg"
			elif name == "Venus":
				self.texture = "data/textures/planets/venus.jpg"
			elif name == "Earth":
				self.texture = "data/textures/planets/earth.jpg"
			elif name == "Mars":
				self.texture = "data/textures/planets/mars.jpg"
			elif name == "Jupiter":
				self.texture = "data/textures/planets/jupiter.jpg"
			elif name == "Saturn":
				self.texture = "data/textures/planets/saturn.jpg"
			elif name == "Uranus":
				self.texture = "data/textures/planets/uranus.jpg"
			elif name == "Neptune":
				self.texture = "data/textures/planets/neptune.jpg"
			elif self.radius/rEarth > 15:
				self.texture = "data/textures/planets/jupiter.jpg"
			elif self.radius/rEarth > 6:
				self.texture = "data/textures/planets/jupiter.jpg"
			elif self.radius/rEarth > 2:
				self.texture = "data/textures/planets/neptune.jpg"
			elif self.radius/rEarth > 1.25:
				self.texture = "data/textures/planets/earth.jpg"
			else:
				self.texture = "data/textures/planets/earth.jpg"
				

class bodyInfo:
	name = ""
	mass = ""
	discovered = 0
	detectionType = ""
	molecules = ""
	isStar = 0
	systemName = ""
	starDistance = 0.0
	starAge = 0.0
	starType = ""
	
	# getter functions
	def __getitem__(self, name):
		return name
	def __getitem__(self, mass):
		return mass
	def __getitem__(self, discovered):
		return discovered
	def __getitem__(self, detectionType):
		return detectionType
	def __getitem__(self, molecules):
		return molecules
	def __getitem__(self, isStar):
		return isStar
	def __getitem__(self, systemName):
		return systemName
	def __getitem__(self, starDistance):
		return starDistance
	def __getitem__(self, starAge):
		return starAge
	def __getitem__(self, starType):
		return starType
	
	# constructor
	def __init__(self, name, mass, discovered, detectionType, molecules, systemName, starDistance, starAge, starType, isStar):
		self.name = name
		if isStar == 0:
			self.mass = str(mass) + "Jupiter Mass"	# Jupiter mass
		else:
			self.mass = str(mass) + "Sun Mass" # Sun Mass
		self.discovered = discovered
		self.detectionType = detectionType
		self.molecules = molecules
		self.isStar = isStar
		self.starType = starType
		self.systemName = systemName
		self.starDistance = starDistance #parsecs
		self.starAge = starAge #Galactic Year
		
		
class habZone:
	starName = ""
	starType = ""
	habInner = 0.0
	habOuter = 0.0
	habCenter = 0.0
	habWidth = 0.0
	
	def __getitem__(self, starName):
		return starName
	def __getitem__(self, statType):
		return starType
	def __getitem__(self, habInner):
		return habInner
	def __getitem__(self, habOuter):
		return habOuter
	def __getitem__(self, habCenter):
		return habCenter
	def __getitem__(self, habWidth):
		return habWidth
	
	def __init__(self, starName, starType):
		self.starName = starName
		self.starType = starType
	
	def calHabitableZone(self):
		if self.starType.find('A') != -1:
			self.habInner = 8.5 * AUtoKM
			self.habOuter = 12.5 * AUtoKM
		elif self.starType.find('F') != -1:
			self.habInner = 1.5 * AUtoKM
			self.habOuter = 2.2 * AUtoKM
		elif self.starType.find('G') != -1:
			self.habInner = 0.95 * AUtoKM
			self.habOuter = 1.4 * AUtoKM
		elif self.starType.find('K') != -1:
			self.habInner = 0.38 * AUtoKM
			self.habOuter = 0.56 * AUtoKM
		elif self.starType.find('M') != -1:
			self.habInner = 0.08 * AUtoKM
			self.habOuter = 0.12 * AUtoKM
		else:
			self.habInner = 0.0
			self.habOuter = 0.0
		self.habCenter = (self.habInner + self.habOuter) * 0.5
		self.habWidth = self.habOuter - self.habInner

		
class starLoc:
	alpha = 0.0 # right ascension in hh:mm:ss convert to degrees
	delta = 0.0 # declination in dd:mm:ss convert to degrees
	distance = 0.0 # distance to star from earth
	pos = Vector3(0.0,0.0,0.0)
	name = ""
	
	def __getitem__(self, pos):
		return pos
	def __getitem__(self, name):
		return name
	
	def __init__(self, name, a, d, dist):
		self.name = name
		ahr = 0.0
		amin = 0.0
		asec = 0.0
		dday = 0.0
		dmin = 0.0
		dsec = 0.0
		part = a.strip().split(":")
		ahr = float(part[0])
		amin = float(part[1])
		asec = float(part[2])
		part = d.strip().split(":")
		sign = part[0][0]
		dday = float(part[0][1:])
		dmin = float(part[1])
		dsec = float(part[2])
		if sign == "-":
			dday = -(float(dday))
			dmin = -(float(dmin))
			dsec = -(float(dsec))
		self.alpha = (float(ahr) * float(HRtoDEG)) + (float(amin) * float(MINtoDEG)) + (float(asec) * float(SECtoDEG))
		self.delta = (float(dday) * float(DAYtoDEG)) + (float(dmin) * float(MINtoDEG)) + (float(dsec) * float(SECtoDEG))
		self.distance = dist
		x = float(self.distance) * float(cos(radians(self.alpha))) * float(cos(radians(self.delta)))
		y = float(self.distance) * float(cos(radians(self.delta))) * float(sin(radians(self.alpha)))
		z = float(self.distance) * float(sin(radians(self.delta)))
		self.pos = Vector3(x * PCtoKM, y * PCtoKM, z * PCtoKM)
		
		
		
# ------------------------------------------------------------------			
# variables

isCave = False

mSun = "1.989E30 kg"

rSun = 695500 # km
rJupiter = 71493.5 # Km
rEarth = 6378 #km

# conversions
AUtoKM = 149597871
PCtoKM = 3.08567e13
PCtoLY = 3.26163344
HRtoDEG = 15.0
DAYtoDEG = 24.0 * HRtoDEG
MINtoDEG = 15.0/60.0
SECtoDEG = 15.0/3600.0


# computer goldilocks zone based on the type of star
# for now setting to the Sun
habInner = 0.95 * AUtoKM
habOuter = 1.4 * AUtoKM
habCenter = 0.5 * (habInner + habOuter)


#wallLimit = 400000000
wallLimit = - 3 * 48000

# scaling
#scale factor for 3d system in the cave
userScaleFactor = 4
# 4 for kepler 11
# 1 for sol

#scale factor for the systems on the walls
user2ScaleFactor = 1
# 30 for kepler 11

orbitScaleFactor = 0.00001
planetScaleFactor = 0.01
sunScaleFactor = 0.001
visualizationScaleFactor = 0.00001
overallScaleFactor = 0.00025
timeFactor = 90

XorbitScaleFactor = 320000.0 / wallLimit
XplanetScaleFactor = 0.25


# time 
DAYtoYEAR = 1.0/365.0

# data variables
allSystemsOrbital = dict()
allSystemsInfo = dict()
#systemList = ["Solar System", "HD 209458", "alf Cen B", "nu Oph", "Kepler-75", "ups And", "CoRoT-11", "XO-3", "Kepler-22", "MOA-2007-BLG-192-L", "Kepler-11", "Kepler-10", "GJ 1214", "Gl 581", "WASP-33", "30 Ari B", "Kepler-39", "HR 8799", "Kepler-65", "Fomalhaut", "KOI-142", "HD 10180", "Kepler-68", "Kepler-20", "24 Sex", "Kepler-42", "HD 39194", "HD 134987", "HD 60532", "HD 96700", "HD 142", "HD 134060", "HD 215152", "HD 217107", "HD 99492", "GJ 676A", "HD 20794", "HD 128311", "14 Her", "HD 136352", "HD 113538", "HD 190360", "mu Ara", "47 Uma", "Gl 163", "Gliese 876", "55 Cnc", "HD 20003", "GJ 667C", "61 Vir", "HD 69830", "HD 40307"]
systemList = ["Solar System", "HD 209458", "alf Cen B", "nu Oph", "Kepler-75", "ups And", "CoRoT-11", "Kepler-22", "Kepler-11", "Kepler-10", "GJ 1214", "Gl 581", "30 Ari B", "Kepler-39", "HR 8799", "Fomalhaut", "KOI-142", "HD 10180", "Kepler-68", "Kepler-20", "24 Sex", "Kepler-42", "HD 39194", "HD 134987", "HD 60532", "HD 96700", "HD 142", "HD 134060", "HD 215152", "HD 217107", "HD 99492", "GJ 676A", "HD 20794", "HD 128311", "14 Her", "HD 136352", "HD 113538", "HD 190360", "mu Ara", "47 Uma", "Gl 163", "Gliese 876", "55 Cnc", "HD 20003", "GJ 667C", "61 Vir", "HD 69830", "HD 40307"]
displaySystemList = systemList
activeSystem = "Solar System"
starLocations = dict()

# dicts to change when scaling 
activeBodies = dict()
activeRotCenters = dict() # do not scale these
habitableZones = dict()
systemNodeDict = dict()
orbitDict = dict()
textDict = dict()
otherObjectsDict = dict()
wallSystemsDict = dict()
wallSystemTextDict = dict()
visualizeDict = dict()
habiInnerDict = dict()
habiOuterDict = dict()
habiWallDict = dict()


# Colors
colorBlack = Color("#000000FF") # Black
colorWhite = Color("#FFFFFFFF") # white
# starColors
colorO = Color("#3E94D1AA") # blue
colorB = Color("#A5E5FFAA") # deep blue white
colorA = Color("#CAF0FFAA") # blue white
colorF = Color("#FFFFFFAA") # white
colorG = Color("#FFEFC0AA") # yellowish white
colorK = Color("#FFD36BAA") # pale yellow orange
colorM = Color("#FFBF86AA") # yellow orange red



currentSystem = "Solar System"




# setting up initial scene hierarchy
# level 1
allSystems = SceneNode.create('allSystems')
vizContainer = SceneNode.create('vizContainer')

# level 2
universe = SceneNode.create('universe')
thingsOnTheWall = SceneNode.create('thingsOnTheWall')
visualization = SceneNode.create('visualization')

# level 3
everything = SceneNode.create('everything')


# Camera Properties
camSpeed = 25

# Cave dependent scaling 
# font
scaleFactor = 2400 if isCave == True else 1 
fontSize = 0.04 * scaleFactor

# Visualization parameters
vizPos = Vector3(10000000000,10000000000,100000000000)

# -----------------------------------------------------------------
# method definitions
# get length of semi major axis using eccentricity and semi major axis

def initSceneNodes():
	for system in systemList:
		temp = SceneNode.create(system)
		systemNodeDict[system] = temp
	for system in systemList:
		universe.addChild(systemNodeDict[system])
	
	visualization.addChild(vizContainer)
	thingsOnTheWall.addChild(allSystems)
	everything.addChild(universe)
	everything.addChild(thingsOnTheWall)
	everything.addChild(visualization)

def starColor(star):
	if star.starType.find('A') != -1:
		return colorA
	elif star.starType.find('B') != -1:
		return colorB
	elif star.starType.find('G') != -1:
		return colorG
	elif star.starType.find('K') != -1:
		return colorK
	elif star.starType.find('F') != -1:
		return colorF
	elif star.starType.find('M') != -1:
		return colorM
	elif star.starType.find('O') != -1:
		return colorO


def getOrbitCoords(e, a):
	ra = (1.0 + e) * a
	rp = (1.0 - e) * a
	b = pow((ra*rp), 0.5)
	return b


def updateOrbitScale(scale):
	global orbitScaleFactor
	orbitScaleFactor = 1.0/pow(10, scale)

	for system in systemList:
		theSystem = allSystemsOrbital[system]
		for name, model in theSystem.iteritems():
			pos = ((Vector3(0.0, 0.0, -theSystem[name].minorA  * orbitScaleFactor * userScaleFactor)))
			pos2 = starLocations[system].pos  * orbitScaleFactor * userScaleFactor
			pos3 = habitableZones[system].habCenter * orbitScaleFactor * userScaleFactor
			pos1 = habitableZones[system].habWidth * orbitScaleFactor * userScaleFactor * 0.00015
			pos2_1 = theSystem[name].minorA * orbitScaleFactor * userScaleFactor
			if theSystem[name].isStar == 0:
				pos4 = Vector3(0, theSystem[name].radius * planetScaleFactor, - theSystem[name].minorA * orbitScaleFactor * userScaleFactor)
			else:
				pos4 = Vector3(0, theSystem[name].radius * sunScaleFactor, - theSystem[name].minorA * orbitScaleFactor * userScaleFactor)
			if (48000 - theSystem[name].minorA * orbitScaleFactor * userScaleFactor * 10) >= wallLimit:
				pos5 = Vector3(0.0, 0.0, 48000 - theSystem[name].minorA * orbitScaleFactor * userScaleFactor * 10)
				pos6 = Vector3(0.0, -10000.0, 48000 - theSystem[name].minorA * orbitScaleFactor * userScaleFactor * 10)
			else:
				pos5 = Vector3(0.0, 0.0, wallLimit)
				pos6 = Vector3(0.0, -10000.0,wallLimit)
			if (48000 - habitableZones[system].habCenter *  orbitScaleFactor * userScaleFactor  * 10) >= wallLimit:
				pos7 = Vector3(0.0, 0.0, 48000 - habitableZones[system].habCenter *  orbitScaleFactor * userScaleFactor  * 10)
			else:
				pos7 = Vector3(0.0,0.0, habitableZones[system].habCenter)
			#pos7 = Vector3(0.0, 0.0, 48000 - habitableZones[system].habCenter *  orbitScaleFactor * userScaleFactor  * 10)
			activeBodies[name].setPosition(pos)
			#activeRotCenters[name].setPosition(pos2)
			orbitDict[name].setScale(Vector3(pos2_1, 10.0, pos2_1))
			textDict[name].setPosition(pos4)
			wallSystemsDict[name].setPosition(pos5)
			if theSystem[name].isStar == 0:
				wallSystemTextDict[name].setPosition(pos6)
			if name == "Saturn":
				otherObjectsDict[name].setPosition(pos)
			habiInnerDict[system].setScale(orbitScaleFactor * userScaleFactor, orbitScaleFactor * userScaleFactor, orbitScaleFactor * userScaleFactor)
			habiOuterDict[system].setScale(orbitScaleFactor * userScaleFactor, orbitScaleFactor * userScaleFactor, orbitScaleFactor * userScaleFactor)
			habiWallDict[system].setPosition(pos7)
			habiWallDict[system].setScale( 1,1 ,  orbitScaleFactor * userScaleFactor )
			
def updatePlanetScale(scale):
	global planetScaleFactor
	planetScaleFactor = 1.0/pow(10, scale)
	
	for system in systemList:
		theSystem = allSystemsOrbital[system]
		for name, model in theSystem.iteritems():
			if theSystem[name].isStar == 0:
				activeBodies[name].setScale(Vector3(theSystem[name].radius * planetScaleFactor, theSystem[name].radius * planetScaleFactor, theSystem[name].radius * planetScaleFactor))
				pos = Vector3(0, theSystem[name].radius * planetScaleFactor, - theSystem[name].minorA * orbitScaleFactor * userScaleFactor)
				textDict[name].setPosition(pos)
			if name == "Saturn":
				otherObjectsDict[name].setScale(planetScaleFactor, planetScaleFactor, planetScaleFactor)
				
	
def updateSunScale(scale):
	global sunScaleFactor
	sunScaleFactor = 1.0/pow(10, scale)
	
	for system in systemList:
		theSystem = allSystemsOrbital[system]
		for name, model in theSystem.iteritems():
			if theSystem[name].isStar == 1:
				activeBodies[name].setScale(Vector3(theSystem[name].radius * sunScaleFactor, theSystem[name].radius * sunScaleFactor, theSystem[name].radius * sunScaleFactor))
				pos = Vector3(0, theSystem[name].radius * sunScaleFactor, - theSystem[name].minorA * orbitScaleFactor * userScaleFactor)
				textDict[name].setPosition(pos)
				

def updateTimeFactor(factor):
	global timeFactor
	timeFactor = (9 - factor) * 10 if (9 - factor) != 0 else 1
	

def getTimeFactor():
	return timeFactor
	
def setActiveSystem(name):
	global activeSystem
	activeSystem = name
	
def getActiveSystem():
	return activeSystem
	
def findInList(object, list):
	for temp in list:
		if object == temp:
			return True
	