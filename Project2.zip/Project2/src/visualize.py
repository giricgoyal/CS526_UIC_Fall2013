# #######################################################
# create the systems in 3D,
# create the wall systems
#
# author: giric goyal
# #######################################################

# -------------------------------------------------------
# imports 
from util import *
from math import *
from euclid import *
from omega import *
from cyclops import *


# -------------------------------------------------------
# variables


# -------------------------------------------------------
# method definitions
